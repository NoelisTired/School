
var attracties = new List<Attractie>();

attracties.Add(new Attractie
{
    Naam = "Debug Hero",
    Soort = "Achtbaan",
    BezoekersPerJaar = 11000,
    LaatsteOnderhoud = 320
});

