using AbboChecker;
var abonnementen = AbonnementenLijst.HaalAbonnementenOp();

bool isRunning = true;
while(isRunning)
{
    Console.Clear();
    Console.WriteLine("1. Toon de gemiddelde leeftijd van alle abonnementhouders");
    Console.WriteLine("2. ...");


    // SCRHIJF HIER JE EIGEN CODE


    Console.WriteLine("Wilt u afsluiten? Ja / Nee");
    string closeAnswer = Console.ReadLine();
    if(closeAnswer == "Ja" || closeAnswer == "ja")
    {
        isRunning = false;
    }

}
